<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Power Tech a Industrial Category Flat Bootstrap Responsive Website Template | Blog :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Power Tech Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android  Compatible web template,Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,800italic,800,700italic,700,600italic,400italic,300italic,300,600' rel='stylesheet' type='text/css'>
<!--/webfont-->
 <!-- Bootstrap core JavaScript-->
<!-- Placed at the end of the document so the pages load faster -->
<!--bootstrap-->
			<link rel="stylesheet" type="text/css" href="css/component.css" />
		<!--css-->
			<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
		<!--coustom css-->
			<link href="css/style.css" rel="stylesheet" type="text/css"/>
		<!--default-js-->
			<script src="js/jquery-2.1.4.min.js"></script>
		<!--bootstrap-js-->
			<script src="js/bootstrap.min.js"></script>

<!-- js -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--/script-->
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
				$("#clientlink").addClass("active");
			});
</script>
</head>
<body>
<?php include ("header.php");?>

<div class="banner banner5"> 
	<div class="container">
		<h2 >Clients</h2>
	</div>	
</div>	
<!--blog-->
<!--blog -->
<div class="blog">
	<div class="container">
			<div class="single-inline wow fadeInLeft animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
				<div class="blog-to">		
					
						<a href="single.html"><img class="img-responsive sin-on" src="images/sin1.jpg" alt="" /></a>
							<div class="blog-top">
							<div class="blog-left">
								<b>14</b>
								<span>Feb</span>
							</div>
							<div class="top-blog">
								<a class="fast" href="single.html">Sed ut perspiciatis unde omnis iste natus error sit voluptatem</a>
								<p>Posted by <a href="single.html">Admin</a> in <a href="#">General</a> | <a href="single.html">10 Comments</a></p> 
								<p class="sed">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500
									 when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap.
									 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500
									 when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap.</p> 
								<a href="single.html" class="hvr-shutter-in-horizontal">Read More</a>
								
							</div>
							<div class="clearfix"> </div>
					</div>
					</div>
							<div class="blog-to">		
					
						<a href="single.html"><img class="img-responsive sin-on" src="images/sin2.jpg" alt="" /></a>
							<div class="blog-top">
							<div class="blog-left">
								<b>19</b>
								<span>July</span>
							</div>
							<div class="top-blog">
								<a class="fast" href="single.html">Sed ut perspiciatis unde omnis iste natus error sit voluptatem</a>
								<p>Posted by <a href="single.html">Admin</a> in <a href="#">General</a> | <a href="single.html">10 Comments</a></p> 
								<p class="sed">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500
									 when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap.
									 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500
									 when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap.</p> 
								<a href="single.html" class="hvr-shutter-in-horizontal">Read More</a>
								
							</div>
							<div class="clearfix"> </div>
					</div>
					</div>
						<div class="blog-to">		
					
						<a href="single.html"><img class="img-responsive sin-on" src="images/sin3.jpg" alt="" /></a>
							<div class="blog-top">
							<div class="blog-left">
								<b>28</b>
								<span>July</span>
							</div>
							<div class="top-blog">
								<a class="fast" href="single.html">Sed ut perspiciatis unde omnis iste natus error sit voluptatem</a>
								<p>Posted by <a href="single.html">Admin</a> in <a href="#">General</a> | <a href="single.html">10 Comments</a></p> 
								<p class="sed">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500
									 when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap.
									 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500
									 when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap.</p> 
								<a href="single.html" class="hvr-shutter-in-horizontal">Read More</a>
								
							</div>
							<div class="clearfix"> </div>
					</div>
					</div>
				</div>
				<nav>
				  <ul class="pagination">
					<li class="disabled"><a href="#" aria-label="Previous"><span aria-hidden="true">«</span></a></li>
					<li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
					<li><a href="#">2 <span class="sr-only"></span></a></li>
					<li><a href="#">3 <span class="sr-only"></span></a></li>
					<li><a href="#">4 <span class="sr-only"></span></a></li>
					<li><a href="#">5 <span class="sr-only"></span></a></li>
					 <li> <a href="#" aria-label="Next"><span aria-hidden="true">»</span> </a> </li>
				  </ul>
				</nav>
			</div>
			</div>
	<!-- //blog -->

<!--/blog-->
<?php include ("footer.php");?>
</body>
</html>		