<div class="header">
	<div class="banner-top">
			<div class="container">
				<!--<p class="location"><i class="glyphicon glyphicon-map-marker"> </i>18A, Polo Street (Yellow Door)</p>-->
						<div class="social-icons">
							<ul>
								<li><a href="#"><i class="facebook"> </i></a></li>
								<li><a href="#"><i class="twitter"> </i></a></li>
								<li><a href="#"><i class="vimeo"> </i></a></li>	
							</ul>
						</div>
					<div class="clearfix"> </div>
			</div>
	</div>
		<!--<div class="logo"><a href="index.html"><h1>Power-Tech</h1></a> </div>-->
        <div class="logo"><img src="images/LOGO11.png"/></div>
        <!--<div class="logo2"><img src="images/header2.png"/></div>-->
</div>
<div class="navigation">
	<div class="container">
		<div class="header-nav">
			<!-- navigation -->
<div class="navigation">		<nav class="navbar navbar-default">
		 
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			</div>

			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
				  <!--<ul class="nav navbar-nav">
                  
                  	<li class="hvr-bounce-to-bottom" id="homelink"><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
					<li class="hvr-bounce-to-bottom" id="aboutlink"><a href="about.php">About us</a></li>
					<li class="hvr-bounce-to-bottom" id="servicelink"><a href="services.php">Services</a></li>
					<li class="hvr-bounce-to-bottom" id="productlink"><a href="products.php">Products</a>
                    	<ul class="nav navbar-nav">
                            <li class="hvr-bounce-to-bottom"><a href="#">Professional</a></li>
                            <li class="hvr-bounce-to-bottom"><a href="#">Bar Refrigerator</a></li>
                            <li class="hvr-bounce-to-bottom"><a href="#">Retail</a></li>
                            <li class="hvr-bounce-to-bottom"><a href="#">Bio medical</a></li>
                        </ul>
                    </li>
					<li class="hvr-bounce-to-bottom" id="clientlink"><a href="clients.php">Clients</a></li>
                    <li class="hvr-bounce-to-bottom" id="careerlink"><a href="career.php">Career</a></li>
                    <li class="hvr-bounce-to-bottom" id="contactlink"><a href="contact.php">Contact Us</a></li>
				  </ul>-->
                  <div class="menubar">
                  <div id="menus">
                  <ul>
                  	<li class="hvr-bounce-to-bottom" id="homelink"><a href="index.php">HOME <span class="sr-only">(current)</span></a></li>
					<li class="hvr-bounce-to-bottom" id="aboutlink"><a href="about.php">ABOUT US</a></li>
					<li class="hvr-bounce-to-bottom" id="servicelink"><a href="services.php">SERVICES</a></li>
					<li class="hvr-bounce-to-bottom" id="productlink"><a href="#">PRODUCTS</a>
                    	<ul>
                            <li class="hvr-bounce-to-bottom"><a href="products.php">PROFESSIONAL REFRIGERATION</a></li>
                            <li class="hvr-bounce-to-bottom"><a href="barref.php">BAR REFRIGERATION</a></li>
                            <li class="hvr-bounce-to-bottom"><a href="retailref.php">RETAIL REFRIGERATION</a></li>
                            <li class="hvr-bounce-to-bottom"><a href="bioref.php">BIO MEDICAL REFRIGERATION</a></li>
                        </ul>
                    </li>
					<li class="hvr-bounce-to-bottom" id="clientlink"><a href="clients.php">CLIENTS</a></li>
                    <!--<li class="hvr-bounce-to-bottom" id="careerlink"><a href="career.php">CAREER</a></li>-->
                    <li class="hvr-bounce-to-bottom" id="contactlink"><a href="contact.php">CONTACT US</a></li>
                  </ul>
                 
                
			  <div class="clearfix"></div>
			</div><!-- /.navbar-collapse -->
		</nav>
	</div>
</div>
<!-- //navigation -->


						  <!-- script-for-menu -->
							 <script>
									$("span.menu").click(function(){
										$(".top-nav ul").slideToggle("slow" , function(){
										});
									});
							 </script>
						<!-- script-for-menu -->
		</div>
	</div>