<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Technochill</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Power Tech Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android  Compatible web template,Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,800italic,800,700italic,700,600italic,400italic,300italic,300,600' rel='stylesheet' type='text/css'>
<!--/webfont-->
 <!-- Bootstrap core JavaScript-->
<!-- Placed at the end of the document so the pages load faster -->
<!--bootstrap-->
			<link rel="stylesheet" type="text/css" href="css/component.css" />
		<!--css-->
			<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
		<!--coustom css-->
			<link href="css/style.css" rel="stylesheet" type="text/css"/>
		<!--default-js-->
			<script src="js/jquery-2.1.4.min.js"></script>
		<!--bootstrap-js-->
			<script src="js/bootstrap.min.js"></script>

<!-- js -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--/script-->
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
				$("#homelink").addClass("active1");
				
				$("a[href='#to-top']").click(function() {
				  $("html, body").animate({ scrollTop: 0 }, "slow");
				  return false;
				});
			});
</script>


  
    <!-- Insert to your webpage before the </head> -->
    <script src="carouselengine/jquery.js"></script>
    <script src="carouselengine/amazingcarousel.js"></script>
    <link rel="stylesheet" type="text/css" href="carouselengine/initcarousel-1.css">
    <script src="carouselengine/initcarousel-1.js"></script>
    <!-- End of head section HTML codes -->


</head>
<body>

<?php include("header.php"); ?>

<div class="banner"> 
<!-- Insert to your webpage where you want to display the carousel -->
<div id="amazingcarousel-container-1">
    <div id="amazingcarousel-1" style="display:none;position:relative;width:100%;max-width:3900px;margin:0px auto 0px;">
        <div class="amazingcarousel-list-container">
            <ul class="amazingcarousel-list">
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="images/Slider-Refrigeration-lightbox.jpg" title="Slider-Refrigeration"  class="html5lightbox" data-group="amazingcarousel-1"><img src="images/Slider-Refrigeration.jpg"  alt="Slider-Refrigeration" /></a></div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="images/Kitchen Refrigeration-lightbox.jpg" title="Kitchen Refrigeration"  class="html5lightbox" data-group="amazingcarousel-1"><img src="images/Kitchen Refrigeration.jpg"  alt="Kitchen Refrigeration" /></a></div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="images/Bar-Refrigeration-lightbox.jpg" title="Bar-Refrigeration"  class="html5lightbox" data-group="amazingcarousel-1"><img src="images/Bar-Refrigeration.jpg"  alt="Bar-Refrigeration" /></a></div>                    </div>
                </li>
            </ul>
            <div class="amazingcarousel-prev"></div>
            <div class="amazingcarousel-next"></div>
        </div>
        <div class="amazingcarousel-nav"></div>
        <div class="amazingcarousel-engine"><a href="http://amazingcarousel.com">JavaScript Image Scroller</a></div>
    </div>
</div>
<!-- End of body section HTML codes -->
</div>	
<!--welcome-->
<div class="welcome">
	<div class="container">
		<div class="col-md-6 wel-img">
			<img src="images/LOGO11.png" alt="image" />
		</div>
		<div class="col-md-6 wel-text">
			<h3>Company profile</h3>
			<p>Techno Chill Services was established in the year 2008. We are service provider of Deep Freezers, Pasty Cabinets, Visi Coolers, Blast Freezers, Air Conditioning Units, Package Air Conditioner, Vapour Absorption Chillers, Water Cooler, Wine Coolers and beer coolers.Supply of any kind of spares of Air Conditioning Systems along with Chillers, also we are giving service for Vapour Absorption Chiller (VAM). Maintenance of Deep Freezers since last Four years by placing emphasis on fair pricing.<br/>
               </p>
			<a href="about.php" class="hvr-shutter-in-horizontal">Read More</a>
		</div>
	</div>
</div>
<!--/welcome-->
<div class="specialty-grids">
	<div class="container">
		<div class="specialty-grids-top">
			<div class="col-md-4 service-box">
				<figure class="icon">
					<i class="glyphicon glyphicon-eye-open"></i>
				</figure>
					<h5>VISION</h5>
					<p style="text-align:justify;">To be recognized as a Best Service Provider engaged in the Refrigeration & HVAC Projects and services around the India.</p>
			</div>
			<div class="col-md-4 service-box ">
				<figure class="icon">
					<i class="glyphicon glyphicon-send"></i>
				</figure>
					<h5>MISSION</h5>
					<p style="text-align:justify;">Our Aspiration is “to provide the best service outcomes for our customers.” To achieve our aspiration we deliver a broad range of Air Conditioning Services from inspections reports through to our programmed maintenance solutions.</p>
			</div>
			<div class="col-md-4 service-box">
				<figure class="icon">
					<i class="glyphicon glyphicon-edit"></i>
				</figure>
				<h5>OBJECTIVES</h5>
				<p style="text-align:justify;">Our Objective is to balance and satisfy our customer’s needs with our people’s needs.</p>
			</div>
						<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!--animation-grids-->
<div class="banner banner5"> 
	<div class="container">
		<h2>OUR PRODUCTS</h2>
	</div>	
</div>
<br/>
<div class="animate-grid">
	<div class="container">
<ul class="grid cs-style-6">
				<li>
					<figure>
						<img src="Products/1.jpg" alt="img01">
						<figcaption>
							<h3>KITCHEN REFRIGERATION</h3>
							<span>EGN-frost free</span>
							<!--<a href="single.html" class="more">More</a>-->
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
						<img src="Products/2.jpg" alt="img05">
						<figcaption>
							<h3>ROOM REFRIGERATION</h3>
							<span>RB-mini bar absorption</span>
							<!--<a href="single.html" class="more">More</a>-->
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
						<img src="Products/3.jpg" alt="img03">
						<figcaption>
							<h3>BAR REFRIGERATION</h3>
							<span>draught beer </span>
							<!--<a href="single.html" class="more">More</a>-->
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
						<img src="Products/4.jpg" alt="img02">
						<figcaption>
							<h3>FREEZER</h3>
							<span>Diamant-semi automatic freezer machine</span>
							<!--<a href="single.html" class="more">More</a>-->
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
						<img src="Products/5.jpg" alt="img04">
						<figcaption>
							<h3>RETAIL REFRIGERATION</h3>
							<span>Confectionery_Showcases</span>
							<!--<a href="single.html" class="more">More</a>-->
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
						<img src="Products/6.jpg" alt="img06">
						<figcaption>
							<h3>BIO MEDICAL REFRIGERATION</h3>
							<span>Upright_Freezers-Frost_Free</span>
							<!--<a href="single.html" class="more">More</a>-->
						</figcaption>
					</figure>
				</li>
			</ul>
			<script src="js/toucheffects.js"></script>
	</div>
</div>
<!--/animation-grids-->
<!--testmonials-->
<!--<div class="testimonials">
	<div class="testimonials-info">
		<div class="col-md-6 testimonials-text">
			<h5>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium.</h5>
		</div>
	</div>
</div>-->
<!--\testmonials-->
<!--news-->
<div class="news">
		<!--<div class="container">
			<div class="news-text">
				<h3>Old Industries</h3>
				<p>Cras porttitor imperdiet volutpat nulla malesuada lectus eros<br><span>ut convallis felis consectetur ut </span></p>
			</div>-->
			<!--<div class="news-grids">
				<div class="col-md-3 news-grid">
					<a href="single.html"><h4>Integer vitae ligula sed lectus</h4></a>
					<span>8.00 - 10.00 | JUN 09,2015</span>
					<a href="single.html" class="mask"><img src="images/img1.jpg" alt="image" class="img-responsive zoom-img"></a>
					<div class="news-info">
						<p>Pellentesque ut urna eu mauris scele risque auctor volutpat et massa pers piciis iste natus scele risque auctor volutpat et massa.</p>
					</div>
				</div>
				<div class="col-md-3 news-grid">
					<a href="single.html"><h4>Integer vitae ligula sed lectus</h4></a>
					<span>10.00 - 12.00 | SEP 24,2015</span>
					<a href="single.html" class="mask"><img src="images/img2.jpg" alt="image" class="img-responsive zoom-img"></a>
					<div class="news-info">
						<p>Pellentesque ut urna eu mauris scele risque auctor volutpat et massa pers piciis iste natus scele risque auctor volutpat et massa.</p>
					</div>
				</div>
				<div class="col-md-3 news-grid">
					<a href="single.html"><h4>Integer vitae ligula sed lectus</h4></a>
					<span>9.00 - 10.00 | FEB 15,2015</span>
					<a href="single.html" class="mask"><img src="images/img3.jpg" alt="image" class="img-responsive zoom-img"></a>
					<div class="news-info">
						<p>Pellentesque ut urna eu mauris scele risque auctor volutpat et massa pers piciis iste natus scele risque auctor volutpat et massa.</p>
					</div>
				</div>
				<div class="col-md-3 news-grid">
					<a href="single.html"><h4>Integer vitae ligula sed lectus</h4></a>
					<span>11.00 - 10.00 | JUN 10,2015</span>
					<a href="single.html" class="mask"><img src="images/img4.jpg" alt="image" class="img-responsive zoom-img"></a>
					<div class="news-info">
						<p>Pellentesque ut urna eu mauris scele risque auctor volutpat et massa pers piciis iste natus scele risque auctor volutpat et massa.</p>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>-->
		</div>
	</div>
<!--news-->
<?php include("footer.php"); ?>

</body>
</html>		