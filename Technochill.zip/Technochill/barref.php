<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Power Tech a Industrial Category Flat Bootstrap Responsive Website Template | Gallery :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Power Tech Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android  Compatible web template,Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,800italic,800,700italic,700,600italic,400italic,300italic,300,600' rel='stylesheet' type='text/css'>
<!--/webfont-->
 <!-- Bootstrap core JavaScript-->
<!-- Placed at the end of the document so the pages load faster -->
<!--bootstrap-->
			<link rel="stylesheet" type="text/css" href="css/component.css" />
			<link rel="stylesheet" href="css/lightbox.css" type="text/css" media="all" />

		<!--css-->
			<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
		<!--coustom css-->
			<link href="css/style.css" rel="stylesheet" type="text/css"/>
		<!--default-js-->
			<script src="js/jquery-2.1.4.min.js"></script>
		<!--bootstrap-js-->
			<script src="js/bootstrap.min.js"></script>

<!-- js -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--/script-->
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
				$("#homelink").addClass("active1");
				
				$("a[href='#to-top']").click(function() {
				  $("html, body").animate({ scrollTop: 0 }, "slow");
				  return false;
				});
			});
</script>
</head>
<body>
<?php include ("header.php");?>

<div class="banner banner5"> 
	<div class="container">
		<h2 >BAR REFRIGERATION</h2>
	</div>	
</div>	
<!--gallery-->
<div class="gallery">
	<div class="container">
		<div class="gallery-bottom">
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="Products/3BAR REFRIGERATION/B1.jpg" data-lightbox="example-set" data-title="17-draught beer "><img class="example-image" src="Products/3BAR REFRIGERATION/B1.jpg" alt=""/></a>
							<figcaption style="background-color:#333;">
							<h4 style="color:rgb(255,255,255); text-align:center;"><strong>draught beer</strong></h4>
							</figcaption>
                            </div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="Products/3BAR REFRIGERATION/B2.jpg" data-lightbox="example-set" data-title="EBB_3D_1-back bar cooler"><img class="example-image" src="Products/3BAR REFRIGERATION/B2.jpg" alt=""/></a>
							<figcaption style="background-color:#333;">
							<h4 style="color:rgb(255,255,255); text-align:center;"><strong>EBB 3D back bar cooler</strong></h4>
							</figcaption>
                            </div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="Products/3BAR REFRIGERATION/B3.jpg" data-lightbox="example-set" data-title="EIM_150_3-ice machine"><img class="example-image" src="Products/3BAR REFRIGERATION/B3.jpg" alt=""/></a>
							<figcaption style="background-color:#333;">
							<h4 style="color:rgb(255,255,255); text-align:center;"><strong>EIM 150 ice machine</strong></h4>
							</figcaption>
                            </div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="Products/3BAR REFRIGERATION/B4.jpg" data-lightbox="example-set" data-title="EWG_50_D_3-wine cooler"><img class="example-image" src="Products/3BAR REFRIGERATION/B4.jpg" alt=""/></a>
							<figcaption style="background-color:#333;">
							<h4 style="color:rgb(255,255,255); text-align:center;"><strong>EWG 50 D wine cooler</strong></h4>
							</figcaption>
                            </div>
							<!--<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="images/g5.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward."><img class="example-image" src="images/g5.jpg" alt=""/></a>
							</div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="images/g6.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward."><img class="example-image" src="images/g6.jpg" alt=""/></a>
							</div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="images/g7.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward."><img class="example-image" src="images/g7.jpg" alt=""/></a>
							</div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="images/g8.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward."><img class="example-image" src="images/g8.jpg" alt=""/></a>
							</div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="images/g9.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward."><img class="example-image" src="images/g9.jpg" alt=""/></a>
							</div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="images/g10.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward."><img class="example-image" src="images/g10.jpg" alt=""/></a>
							</div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="images/g11.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward."><img class="example-image" src="images/g11.jpg" alt=""/></a>
							</div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="images/g12.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward."><img class="example-image" src="images/g12.jpg" alt=""/></a>
							</div>-->
							<div class="clearfix"> </div>
		</div>
	</div>
</div>
<script src="js/lightbox.js"></script>
<!--/gallery-->
<?php include ("footer.php");?>
</body>
</html>		