<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Power Tech a Industrial Category Flat Bootstrap Responsive Website Template | Gallery :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Power Tech Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android  Compatible web template,Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,800italic,800,700italic,700,600italic,400italic,300italic,300,600' rel='stylesheet' type='text/css'>
<!--/webfont-->
 <!-- Bootstrap core JavaScript-->
<!-- Placed at the end of the document so the pages load faster -->
<!--bootstrap-->
			<link rel="stylesheet" type="text/css" href="css/component.css" />
			<link rel="stylesheet" href="css/lightbox.css" type="text/css" media="all" />

		<!--css-->
			<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
		<!--coustom css-->
			<link href="css/style.css" rel="stylesheet" type="text/css"/>
		<!--default-js-->
			<script src="js/jquery-2.1.4.min.js"></script>
		<!--bootstrap-js-->
			<script src="js/bootstrap.min.js"></script>

<!-- js -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--/script-->
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
				$("#homelink").addClass("active1");
				
				$("a[href='#to-top']").click(function() {
				  $("html, body").animate({ scrollTop: 0 }, "slow");
				  return false;
				});
			});
</script>
</head>
<body>
<?php include ("header.php");?>

<div class="banner banner5"> 
	<div class="container">
		<h2 >PROFESSIONAL KITCHEN REFRIGERATION</h2>
	</div>	
</div>	
<!--gallery-->
<div class="gallery">
	<div class="container">
		<div class="gallery-bottom">
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="Products/1PROFESSIONAL KITCHEN REFRIGERATION/p1.jpg" data-lightbox="example-set" data-title="EGN_14.1_C4-F4_2-frost free"><img class="example-image" src="Products/1PROFESSIONAL KITCHEN REFRIGERATION/p1.jpg" alt=""/></a>
							<figcaption style="background-color:#333;">
							<h4 style="color:rgb(255,255,255); text-align:center;"><strong>EGN 14.1 C4-F4 frost free</strong></h4>
							</figcaption>
                            </div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="Products/1PROFESSIONAL KITCHEN REFRIGERATION/p2.jpg" data-lightbox="example-set" data-title="EGN_3100-frost free"><img class="example-image" src="Products/1PROFESSIONAL KITCHEN REFRIGERATION/p2.jpg" alt=""/></a>
							<figcaption style="background-color:#333;">
							<h4 style="color:rgb(255,255,255); text-align:center;"><strong>EGN 3100-frost free</strong></h4>
							</figcaption>
                            </div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="Products/6BIO MEDICAL REFRIGERATION/bio3.jpg" data-lightbox="example-set" data-title="EIM_150_1-ice machine"><img class="example-image" src="Products/6BIO MEDICAL REFRIGERATION/bio3.jpg" alt=""/></a>
							<figcaption style="background-color:#333;">
							<h4 style="color:rgb(255,255,255); text-align:center;"><strong>EIM 50 ice machine</strong></h4>
							</figcaption>
                            </div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="Products/1PROFESSIONAL KITCHEN REFRIGERATION/p4.jpg" data-lightbox="example-set" data-title="ESH_3000_1-salad"><img class="example-image" src="Products/1PROFESSIONAL KITCHEN REFRIGERATION/p4.jpg" alt=""/></a>
							<figcaption style="background-color:#333;">
							<h4 style="color:rgb(255,255,255); text-align:center;"><strong>ESH 3000 salad</strong></h4>
							</figcaption>
                            </div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="Products/1PROFESSIONAL KITCHEN REFRIGERATION/p5.jpg" data-lightbox="example-set" data-title="RI_500-static"><img class="example-image" src="Products/1PROFESSIONAL KITCHEN REFRIGERATION/p5.jpg" alt=""/></a>
							<figcaption style="background-color:#333;">
							<h4 style="color:rgb(255,255,255); text-align:center;"><strong>RI 500-static</strong></h4>
							</figcaption>
                            </div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="Products/1PROFESSIONAL KITCHEN REFRIGERATION/p6.jpg" data-lightbox="example-set" data-title="UC_1500_2-static"><img class="example-image" src="Products/1PROFESSIONAL KITCHEN REFRIGERATION/p6.jpg" alt=""/></a>
							<figcaption style="background-color:#333;">
							<h4 style="color:rgb(255,255,255); text-align:center;"><strong>UC 1500 static</strong></h4>
							</figcaption>
                            </div>
							<!--<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="images/g7.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward."><img class="example-image" src="images/g7.jpg" alt=""/></a>
							</div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="images/g8.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward."><img class="example-image" src="images/g8.jpg" alt=""/></a>
							</div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="images/g9.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward."><img class="example-image" src="images/g9.jpg" alt=""/></a>
							</div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="images/g10.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward."><img class="example-image" src="images/g10.jpg" alt=""/></a>
							</div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="images/g11.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward."><img class="example-image" src="images/g11.jpg" alt=""/></a>
							</div>
							<div class="col-md-3 gallery-grid">
								<a class="example-image-link" href="images/g12.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward."><img class="example-image" src="images/g12.jpg" alt=""/></a>
							</div>-->
							<div class="clearfix"> </div>
		</div>
	</div>
</div>
<script src="js/lightbox.js"></script>
<!--/gallery-->
<?php include ("footer.php");?>
</body>
</html>		