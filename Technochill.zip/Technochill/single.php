<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Power Tech a Industrial Category Flat Bootstrap Responsive Website Template | Single :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Power Tech Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android  Compatible web template,Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,800italic,800,700italic,700,600italic,400italic,300italic,300,600' rel='stylesheet' type='text/css'>
<!--/webfont-->
 <!-- Bootstrap core JavaScript-->
<!-- Placed at the end of the document so the pages load faster -->
<!--bootstrap-->
			<link rel="stylesheet" type="text/css" href="css/component.css" />
		<!--css-->
			<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
		<!--coustom css-->
			<link href="css/style.css" rel="stylesheet" type="text/css"/>
		<!--default-js-->
			<script src="js/jquery-2.1.4.min.js"></script>
		<!--bootstrap-js-->
			<script src="js/bootstrap.min.js"></script>

<!-- js -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--/script-->
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
			});
</script>
</head>
<body>
<div class="header">
	<div class="banner-top">
			<div class="container">
				<!--<p class="location"><i class="glyphicon glyphicon-map-marker"> </i>18A, Polo Street (Yellow Door)</p>-->
						<div class="social-icons">
							<ul>
								<li><a href="#"><i class="facebook"> </i></a></li>
								<li><a href="#"><i class="twitter"> </i></a></li>
								<li><a href="#"><i class="vimeo"> </i></a></li>	
							</ul>
						</div>
					<div class="clearfix"> </div>
			</div>
	</div>
		<!--<div class="logo"><a href="index.html"><h1>Power-Tech</h1></a> </div>-->
        <div class="logo"><img src="images/technochill.png"/></div>
        <div class="logo2"><img src="images/header2.png"/></div>
</div>
<div class="navigation">
	<div class="container">
		<div class="header-nav">
			<!-- navigation -->
<div class="navigation">
		<nav class="navbar navbar-default">
		 
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			</div>

			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
				  <ul class="nav navbar-nav">
					<li class="hvr-bounce-to-bottom"><a href="index.html">Home <span class="sr-only">(current)</span></a></li>
					<li class="hvr-bounce-to-bottom"><a href="about.html">About Us</a></li>
					<li class="hvr-bounce-to-bottom"><a href="shortcodes.html">Services</a></li>
					<li class="hvr-bounce-to-bottom"><a href="gallery.html">Products</a></li>
					<li class="hvr-bounce-to-bottom"><a href="blog.html">Clients</a></li>
                    <li class="hvr-bounce-to-bottom"><a href="career.html">Career</a></li>
					<li class="hvr-bounce-to-bottom"><a href="contact.html">Contact Us</a></li>
				  </ul>
			  <div class="clearfix"></div>
			</div><!-- /.navbar-collapse -->
		</nav>
	</div>
</div>
<!-- //navigation -->


						  <!-- script-for-menu -->
							 <script>
									$("span.menu").click(function(){
										$(".top-nav ul").slideToggle("slow" , function(){
										});
									});
							 </script>
						<!-- script-for-menu -->
		</div>
	</div>
<div class="banner banner5"> 
	<div class="container">
		<h2 >Single Page</h2>
	</div>	
</div>	
<!--single-->
<!--single_page -->
<div class="container">
				<div class="single wow fadeInLeft animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
					<div class="blog-to">		
					
						<img class="img-responsive sin-on" src="images/sin4.jpg" alt="" />
							<div class="blog-top">
							<div class="blog-left">
								<b>23</b>
								<span>July</span>
							</div>
							<div class="top-blog">
								<a class="fast" href="#">It is a long established fact that a reader will be distracted </a>
								<p>Posted by <a href="#">Admin</a> in <a href="#">General</a> | <a href="#">10 Comments</a></p> 
								<p class="sed">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500
									 when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap.
									 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500
									 when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap.</p> 
									 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque malesuada purus a convallis dictum. Phasellus sodales varius diam, non sagittis lectus. Morbi id magna ultricies ipsum condimentum scelerisque vel quis felis. Donec et purus nec leo interdum sodales nec sit amet magna.</p>
								<div class="col-md-6 md-in">
						<ul class="grid-part">
							<li><a href="#"><i class="sign"> </i>Sed ut perspiciatis unde omnis</a></li>
							<li><a href="#"><i class="sign"> </i>Lorem ipsum dolor sit amet,  </a></li>
							<li><a href="#"><i class="sign"> </i>Sed ut perspiciatis unde omnis</a></li>
							<li><a href="#"><i class="sign"> </i>Lorem ipsum dolor sit amet,  </a></li>
							<li><a href="#"><i class="sign"> </i>Sed ut perspiciatis unde omnis</a></li>
						</ul>
						</div>
						<div class="col-md-6 md-in">
						<ul class="grid-part">
							<li><a href="#"><i class="sign"> </i>Sed ut perspiciatis unde omnis</a></li>
							<li><a href="#"><i class="sign"> </i>Lorem ipsum dolor sit amet,  </a></li>
							<li><a href="#"><i class="sign"> </i>Sed ut perspiciatis unde omnis</a></li>
							<li><a href="#"><i class="sign"> </i>Lorem ipsum dolor sit amet,  </a></li>
							<li><a href="#"><i class="sign"> </i>Sed ut perspiciatis unde omnis</a></li>
						</ul>
						</div>
						<div class="clearfix"> </div>
							</div>
							<div class="clearfix"> </div>
					</div>
					</div>		
		<div class="single-middle">
			
			<h3>3 Comments</h3>
				<div class="media">
				  <div class="media-left">
					<a href="#">
					  <img class="media-object" src="images/co.png" alt="">
					</a>
				  </div>
				  <div class="media-body">
					<h4 class="media-heading"><a href="#">Richard Spark</a></h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
					Duis aute irure dolor in reprehenderit .</p>
					<p class="reply"><a href="#"><i class="glyphicon glyphicon-repeat"> </i>Reply</a></p>
				  </div>
				</div>
				<div class="media in-media">
				  <div class="media-left">
					<a href="#">
					  <img class="media-object" src="images/co.png" alt="">
					</a>
				  </div>
				   <div class="media-body">
					<h4 class="media-heading"><a href="#">Joseph Goh</a></h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
					Duis aute irure dolor in reprehenderit .</p>
					<p class="reply"><a href="#"><i class="glyphicon glyphicon-repeat"> </i>Reply</a></p>
				  </div>
				</div>
				<div class="media">
				  <div class="media-left">
					<a href="#">
					  <img class="media-object" src="images/co.png" alt="">
					</a>
				  </div>
				  <div class="media-body">
					<h4 class="media-heading"><a href="#">Melinda Dee</a></h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
					Duis aute irure dolor in reprehenderit .</p>
					<p class="reply"><a href="#"><i class="glyphicon glyphicon-repeat"> </i>Reply</a></p>
				  </div>
				</div>
			
		</div>
		<div class="single-bottom">
		
			<h3>Leave a Comment</h3>
				<form>
						<div class="col-md-4 comment">
						<input type="text" value="Name" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='Name';}">
						</div>
						<div class="col-md-4 comment">
						<input type="text" value="Email" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='Email';}">
						</div>
						<div class="col-md-4 comment">
						<input type="text" value="Subject" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='Subject';}">
						</div>
						<div class="clearfix"> </div>
						<textarea cols="77" rows="6" onfocus="this.value='';" onblur="if (this.value == '') {this.value = 'Message';}">Message</textarea>
						
							<input type="submit" value="Send" >
						
				</form>
			</div>
		</div>
	</div>
	<!-- /single_page -->
<!--/single-->
<div class="footer">
		<div class="container">
			<div class="footer-grids">				
				<div class="col-md-4 recent-posts">
					<h4>Recent Posts</h4>
					<div class="recent-posts-text">
						<h5>MARCH 30, 2015</h5>
						<a href="#"><p>Duis autem vel eum iriure dolor</p></a>
					</div>
					<div class="recent-posts-text">
						<h5>MARCH 15, 2015</h5>
						<a href="#"><p>Duis autem vel eum iriure dolor</p></a>
					</div>
					<div class="recent-posts-text">
						<h5>MARCH 3, 2015</h5>
						<a href="#"><p>Duis autem vel eum iriure dolor</p></a>
					</div>
				</div>
				<div class="col-md-4 recent-posts">
					<h4>Twitter Feeds</h4>
					<div class="recent-posts-text">
						<a href="#"><h5>about 2 days ago<span>@kristit</span></h5></a>
						<a href="#"><p>Good work buddy</p></a>
					</div>
					<div class="recent-posts-text">
						<a href="#"><h5>about 4 days ago <span>@fasteven</span></h5></a>
						<a href="#"><p>Good work buddy</p></a>
					</div>
					<div class="recent-posts-text">
						<a href="#"><h5>about 6 days ago <span>@streamer</span> </h5></a>
						<a href="#"><p>Good work buddy</p></a>
					</div>
				</div>
				<div class="col-md-4 recent-posts">
					<h4>Our Address</h4>
					<p class="adrs">Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus,
						 facilisi Nam liber tempor cum soluta </p>
					<ul>
						<li><span></span>Moonshine St. 14/05 Light, Japan</li>
						<li><span class="ph-no"></span>+00 (123) 111 11 11</li>
						<li><span class="mail"></span><a href="mailto:example@mail.com">mail@example.com</a></li>
					</ul>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>	
	</div>
<div class="copyrights">
<div class="container">
			<div class="copyright-left">
			<p>Copyrights © 2016 Techno Chill. All Rights Reserved | Design by <a href="http://w3layouts.com/">W3layouts</a></p>
			</div>
			<div class="copyright-right">
				<ul>
					<li><a href="#" class="twitter"> </a></li>
					<li><a href="#" class="twitter facebook"> </a></li>
					<li><a href="#" class="twitter chrome"> </a></li>
					<li><a href="#" class="twitter pinterest"> </a></li>
					<li><a href="#" class="twitter linkedin"> </a></li>
					<li><a href="#" class="twitter dribbble"> </a></li>
				</ul>
			</div>
			<div class="clearfix"> </div>
			
		</div>
<!---->
<script type="text/javascript">
		$(document).ready(function() {
				/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
				*/
		$().UItoTop({ easingType: 'easeOutQuart' });
});
</script>
<a href="#to-top" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!----> 
</div>
</body>
</html>		