<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Power Tech a Industrial Category Flat Bootstrap Responsive Website Template | Contact :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Power Tech Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android  Compatible web template,Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,800italic,800,700italic,700,600italic,400italic,300italic,300,600' rel='stylesheet' type='text/css'>
<!--/webfont-->
 <!-- Bootstrap core JavaScript-->
<!-- Placed at the end of the document so the pages load faster -->
<!--bootstrap-->
			<link rel="stylesheet" type="text/css" href="css/component.css" />
		<!--css-->
			<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
		<!--coustom css-->
			<link href="css/style.css" rel="stylesheet" type="text/css"/>
		<!--default-js-->
			<script src="js/jquery-2.1.4.min.js"></script>
		<!--bootstrap-js-->
			<script src="js/bootstrap.min.js"></script>

<!-- js -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--/script-->
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
				$("#homelink").addClass("active1");
				
				$("a[href='#to-top']").click(function() {
				  $("html, body").animate({ scrollTop: 0 }, "slow");
				  return false;
				});
			});
</script>
</head>
<body>
<?php include ("header.php");?>

<div class="banner banner5"> 
	<div class="container">
		<h2 >Contact Us</h2>
	</div>	
</div>	
<!--contact-->
	<div class="mail">
		<div class="container">
			<div class="map footer-middle">
				<!--<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d158858.18237072596!2d-0.10159865000003898!3d51.52864165000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1436514341845" allowfullscreen=""> </iframe>-->
				<iframe src="https://www.google.com/maps/d/embed?mid=ztuJBCexcLx8.kUPbJ_duYRb0" width="1170" height="430"></iframe>
			</div>
			<div class="mail-grids">
				<div class="col-md-6 mail-grid-left">
					<h3>Contact Us</h3>
					<h5>Contact Name :  Mr. Sandesh Vetkar</span></h5>
					<h4>Headquarters</h4>
					<p>A-4, Yogeswar CHS., Patil Wadi,
						<span>Behind Dhakli Dham Society, Kopari,</span>
						Thane [E] - 400 603, Maharashtra , India.
					</p>
					<h4>Get In Touch</h4>
					<p>Mobile : +91 – 9892984414 / +91 – 8879776088<br/>
						<!--<span>FAX: +1 234 567 9871</span>-->
						E-mail: <a href="#">service@technochill.in</a> / <a href="#">info@technochill.in</a>
					</p>
				</div>
				<div class="col-md-6 contact-form">
					<form>
						<input type="text" placeholder="Name" required>
						<input type="text" placeholder="Email" required>
						<input type="text" placeholder="Subject" required>
						<textarea placeholder="Message" required></textarea>
						<input type="submit" value="SEND">
					</form>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!--/contact-->

</body>
</html>		