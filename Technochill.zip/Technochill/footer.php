<div class="footer">
		<div class="container">
			<div class="footer-grids">				
				
				<div class="copyright-right">
				<ul>
					<li><a href="#" class="twitter"> </a></li>
					<li><a href="#" class="twitter facebook"> </a></li>
					<li><a href="#" class="twitter chrome"> </a></li>
					<li><a href="#" class="twitter pinterest"> </a></li>
					<li><a href="#" class="twitter linkedin"> </a></li>
					<!--<li><a href="#" class="twitter dribbble"> </a></li>-->
				</ul>
			</div>
				
				<div class="col-md-4 recent-posts">
					<h4>Our Address</h4>
					<p class="adrs">A - 4, Yogeswar  CHS., Patil Wadi, Behind Dhakli Dham Society, Kopari, Thane [E] - 400 603.</p>
					<ul>
						<li><span></span>Maharashtra , India</li>
						
					</ul>
					</div>
					<!--<div class="recent-posts-text">
						<a href="#"><h5>about 6 days ago <span>@streamer</span> </h5></a>
						<a href="#"><p>Good work buddy</p></a>
					</div>-->
				</div>
				<div class="col-md-4 recent-posts">
					<p class="adrs">
					<ul>
						
						<li><span class="ph-no"></span>+91 – 9892984414 / +91 – 8879776088</li>
						<li><span class="mail"></span><a href="#">info@technochill.in</a></li>
                        <li><span class="mail"></span><a href="#">service@technochill.in</a></li>
					</ul>
                    </p>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>	
	</div>
    
   <div class="copyrights">
<div class="container">
			<div class="copyright-left">
			<p>Copyrights © 2016 Techno Chill. All Rights Reserved | Design by <a href="http://vrwebtek.com/">vrWebTek Solutions</a></p>
			</div>
			<!--<div class="copyright-right">
				<ul>
					<li><a href="#" class="twitter"> </a></li>
					<li><a href="#" class="twitter facebook"> </a></li>
					<li><a href="#" class="twitter chrome"> </a></li>
					<li><a href="#" class="twitter pinterest"> </a></li>
					<li><a href="#" class="twitter linkedin"> </a></li>
					<li><a href="#" class="twitter dribbble"> </a></li>
				</ul>
			</div>-->
			<div class="clearfix"> </div>
			
		</div>
<!---->
<script type="text/javascript">
var js=$.noConflict();
		js(document).ready(function() {
				/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
				*/
		//js().UItoTop({ easingType: 'easeOutQuart' });
});
</script>
<a href="#to-top" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!----> 
</div> 