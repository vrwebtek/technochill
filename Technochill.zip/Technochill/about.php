<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Power Tech a Industrial Category Flat Bootstrap Responsive Website Template | About :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Power Tech Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android  Compatible web template,Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,800italic,800,700italic,700,600italic,400italic,300italic,300,600' rel='stylesheet' type='text/css'>
<!--/webfont-->
 <!-- Bootstrap core JavaScript-->
<!-- Placed at the end of the document so the pages load faster -->
<!--bootstrap-->
			<link rel="stylesheet" type="text/css" href="css/component.css" />
		<!--css-->
			<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
		<!--coustom css-->
			<link href="css/style.css" rel="stylesheet" type="text/css"/>
		<!--default-js-->
			<script src="js/jquery-2.1.4.min.js"></script>
		<!--bootstrap-js-->
			<script src="js/bootstrap.min.js"></script>

<!-- js -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--/script-->
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
				$("#homelink").addClass("active1");
				
				$("a[href='#to-top']").click(function() {
				  $("html, body").animate({ scrollTop: 0 }, "slow");
				  return false;
				});
			});
</script>
</head>
<body>
<?php include("header.php"); ?>

<div class="banner banner5"> 
	<div class="container">
		<h2 >About Us</h2>
	</div>	
</div>	
<!--about-->
<!--start-about-->
	<div class="about two">
		<div class="container">
				<div class="about-top">
					<div class="col-md-7 about-top-right" style="margin-top:-2%;">
						<!--<h4>Techno Chill Services was established in the year 2008. We are service provider of Deep Freezers, Pasty Cabinets, Visi Coolers, Blast Freezers, Air Conditioning Units, Package Air Conditioner, Vapour Absorption Chillers, Water Cooler, Wine Coolers and beer coolers. </h4>-->
						<p style="text-align:justify;">Techno Chill Services was established in the year 2008. We are service provider of Deep Freezers, Pasty Cabinets, Visi Coolers, Blast Freezers, Air Conditioning Units, Package Air Conditioner, Vapour Absorption Chillers, Water Cooler, Wine Coolers and beer coolers.<br/>
                       Supply of any kind of spares of Air Conditioning Systems along with Chillers, also we are giving service for Vapour Absorption Chiller (VAM). Maintenance of Deep Freezers since last Four years by placing emphasis on fair pricing, good service and excellent workmanship, we have gain  a reputation for professionalism and as a result the company has enjoyed an extremely rapid rate of growth. As a result of the company reputation, approximately fifty per cent of our business is derived from referrals from annual AMC in companies as well as other customer referrals.<br/>
                        As a result of increasing emphasis on good service and the change in customer’s needs, we are quickly into and AMC out emphasis is on initially assessing customer’s needs, and then providing solutions to specific problems.</p>
					</div>
                    
					<div class="col-md-5 about-top-left" style="margin-top:-2%;     padding-left: 8%;">
						<h3>News And Annousments</h3><h5> </h5><div class="clearfix"> </div>
						<div class="about-team">
							<div class="client">
								<div class="about-team-left">
									<a href="#"></a>
								</div>
								<div class="about-team-right">
									<p>COMING SOON</p>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="client">
								<div class="about-team-left">
									<a href="#"></a>
								</div>
								<div class="about-team-right">
									<p>COMING SOON</p>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="client">
								<div class="about-team-left">
									<a href="#"></a>
								</div>
								<div class="about-team-right">
									<p>COMING SOON</p>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="client">
								<div class="about-team-left">
									<a href="#"></a>
								</div>
								<div class="about-team-right">
									<p>COMING SOON</p>
								</div>
								<div class="clearfix"> </div>
							</div>
						</div>
					</div>
                    <div class="col-md-7 about-top-right" style="margin-top:1%; width:100%;">
					<div class="grid_3 grid_4">
		     <h3 class="first">OUR BUSINESS PHILOSOPHY:</h3>
		     <div class="bs-example">
             <p style="color:rgb(0,0,0);">1. To listen to our Customers. <br/>
             	2. Their wants, needs and wishes are our strategic blueprint. <br/>
                3. To quantify all aspects of our business in order to create benchmark for success.<br/>
                4. To emphasize quality and we believe that good enough never is.<br/>
                5. To respond quickly and decisively to opportunity.<br/>
                6. To create an environment where ideas are encouraged, recognized and rewarded.<br/>
                7. To work together toward our goals and be rewarded together when they are achieved. <br/>
                8. To commit to leadership in every aspect of our business.
             </p>
             
              <h3 class="first">OUR VALUES AND APPROACH TO ASSURE QUALITY SERVICE:</h3>
		     <p style="color:rgb(0,0,0);">Core Values:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Integrity, Respect, Innovation. <br/>
             	Horizon Values:&nbsp;&nbsp;&nbsp;&nbsp;Imagination, Passion. <br/>
                Service:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Service is the value that bridges our past and future. Is captures our reliability, quality and excellent performance for customers.<br/>
                Our Core Goal:&nbsp;&nbsp;&nbsp;&nbsp;We will create the most respected name in the Ice Cream Freezer Industry.<br/>
                Our Future:	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;We will be a successful company when we make and keep our promises to:<br/>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;....Our Customers<br/>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;....Our Communities and<br/>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;....Our Employees.
             </p>
             </div>
             
			</div>
		<div class="clearfix"></div>
	</div>
    </div>	 
	</div>
	<!--start-team-->
		
	<!--//team-->
	<!--start-camps-->
		<div class="camps">
	    <div class="container">
				<h3 class="tittle">Recent Work</h3>
			 <div class="cam-top-top">
				<div class="col-md-7 cam-top">
					<iframe src="https://www.youtube.com/embed/9l7JqonyoKA" allowfullscreen></iframe>
				</div>
				<div class="col-md-5 cam-top-text">
				   <div class="sub-cam-top">
				       <div class="col-md-4 sub-img">
							<img src="Products/v1.png" alt="img07"/>
					   </div>
					   <div class="col-md-8 sub-text">
					   		 <a href="#">VISON</a>
							 <p style="text-align:justify;">To be recognized as a Best Service Provider engaged in the Refrigeration & HVAC Projects and services around the India.</p>
					   </div>
					    <div class="clearfix"> </div>
				   </div>
				    <div class="sub-cam-top">
				       <div class="col-md-4 sub-img">
							<img src="Products/v2.png" alt="img07"/>
					   </div>
					   <div class="col-md-8 sub-text">
					   		 <a href="#">MISSION</a>
							 <p style="text-align:justify;">Our Aspiration is “to provide the best service outcomes for our customers.” To achieve our aspiration we deliver a broad range of Air Conditioning Services from inspections reports through to our programmed maintenance solutions.</p>
					   </div>
					    <div class="clearfix"> </div>
				   </div>
				    <div class="sub-cam-top">
				       <div class="col-md-4 sub-img">
							<img src="Products/v3.png" alt="img07"/>
					   </div>
					   <div class="col-md-8 sub-text">
					   		 <a href="#">Objective</a>
							 <p>Our Objective is to balance and satisfy our customer’s needs with our people’s needs.</p>
					   </div>
					    <div class="clearfix"> </div>
				   </div>
				</div>
				 <div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!--/about-->
<?php include("footer.php"); ?>
</body>
</html>		